"""Assemble complete finite cohort without modifying any preserved data."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):
    with p.open('x') as f: json.dump(x,f,ensure_ascii=False,indent=2); f.write('\n')

def main():
    old=BASE/'ICSE2027_6658_ResponseCompletion_20261105_v3/all_gold_matched/candidates.json'
    kp=BASE/'review_swe/data/review_packets/verified/packets_key.json'
    pp=kp.with_name('packets.jsonl')
    cs=json.loads(old.read_text()); gold={c['instance_id']:c for c in cs if c['kind']=='gold'}
    keys={k['packet_id']:k for k in json.loads(kp.read_text())}
    n=0
    for line in pp.read_text().splitlines():
        p=json.loads(line);k=keys[p['packet_id']]
        if k['candidate_source']!='agent': continue
        assert k['resolved'] is True
        g=gold[k['instance_id']]
        assert p['repo']==g['repo'] and p['base_commit']==g['base_commit'] and p['issue_text']==g['issue'] and p['diff'].strip()
        cs.append({'code':'r_'+k['instance_id'],'instance_id':k['instance_id'],'kind':'resolved_agent','splits':['verified'],'original_packet_id':p['packet_id'],'repo':p['repo'],'base_commit':p['base_commit'],'issue':p['issue_text'],'diff':p['diff']});n+=1
    assert n==194 and len(cs)==1203 and len({c['code'] for c in cs})==1203
    assert Counter(c['kind'] for c in cs)=={'gold':707,'resolved_agent':194,'unresolved_agent':302}
    assert len({c['instance_id'] for c in cs if c['kind']!='gold'})==496
    cs.sort(key=lambda c:hashlib.sha256(('6658:'+c['code']).encode()).hexdigest())
    dump(ROOT/'inputs/candidates.json',cs)
    cfg={'seed':6658,'dtype':'float16','max_model_len':32768,'max_tokens':1200,'temperature':0.0,'gpu_memory_utilization':0.88,'max_num_seqs':24,'max_num_batched_tokens':4096,'models':{
        '7b':{'model_path':'/workspace/models/huggingface/Qwen/Qwen2.5-Coder-7B-Instruct/c03e6d358207e414f1eca0bb1891e29f1db0e242','revision':'c03e6d358207e414f1eca0bb1891e29f1db0e242','quantization':None},
        '14b':{'model_path':'/workspace/models/huggingface/Qwen/Qwen2.5-Coder-14B-Instruct-AWQ/eb3172f06a6d6b3a15f08947b0668d782e4d2d2c','revision':'eb3172f06a6d6b3a15f08947b0668d782e4d2d2c','quantization':'awq_marlin'}}}
    dump(ROOT/'inputs/config.json',cfg)
    shutil.copyfile(BASE/'ICSE2027_6658_Rerun_20261106_v14/runtime_requirements_v8.txt',ROOT/'runtime_requirements.txt')
    source=[old,kp,pp]
    dump(ROOT/'evidence/source_manifest.json',{'created_at_utc':datetime.now(timezone.utc).isoformat(),'sources':[{'path':str(p),'sha256':sha(p)} for p in source],'cohort':dict(Counter(c['kind'] for c in cs)),'gold_lite':sum(c['kind']=='gold' and 'lite' in c['splits'] for c in cs),'gold_verified':sum(c['kind']=='gold' and 'verified' in c['splits'] for c in cs),'missing_nonempty_agent_candidates':4,'planned_per_model':4812})
    print('Prepared1203 candidates; 4812 records/model; no inference yet.')

if __name__=='__main__': main()
