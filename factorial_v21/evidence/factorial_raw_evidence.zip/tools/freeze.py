"""Seal protocol, inference and analysis before scientific generation."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
cfg=json.loads((ROOT/'inputs/config.json').read_text())
paths=[ROOT/'PROTOCOL.md',ROOT/'runtime_requirements.txt',ROOT/'evidence/source_manifest.json']
paths+=list(sorted((ROOT/'tools').glob('*.py')))+[ROOT/'tools/run_gpu.sh']
paths+=list(sorted((ROOT/'inputs').glob('*.json')))
for m in cfg['models'].values():
    for name in ['config.json','generation_config.json','tokenizer_config.json','tokenizer.json','model.safetensors.index.json']:
        p=Path(m['model_path'])/name
        if p.exists():paths.append(p)
record={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'no_scientific_inference_outputs_exist':not any(ROOT.glob('run_*/records/*.json')),'all_weight_shards_independently_rehashed':False,'files':[{'path':str(p),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]}
assert record['no_scientific_inference_outputs_exist']
with (ROOT/'FREEZE.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('FROZEN',record['frozen_at_utc'],len(paths))
