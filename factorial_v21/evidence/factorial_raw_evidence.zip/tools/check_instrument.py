"""Small useful checks of factor independence, parsing, and acceptance boundary."""
import copy
import json
from prompts import ARMS, BASE, EXPLANATION, BLOCKING, messages, parse, accepted

c={'repo':'r','base_commit':'c','issue':'example issue','diff':'example diff','kind':'gold'}
ss={arm:messages(arm,c) for arm in ARMS}
assert len({ss[a][1]['content'] for a in ARMS})==1
assert ss['E1B0'][0]['content']==BASE+EXPLANATION
assert ss['E0B1'][0]['content']==BASE+BLOCKING
assert ss['E1B1'][0]['content']==BASE+EXPLANATION+BLOCKING
other={**c,'kind':'unresolved_agent'}
assert all(messages(a,c)==messages(a,other) for a in ARMS)
v={'summary':'fine','issues':[],'merge_decision':'merge','confidence':0.5}
assert parse(json.dumps(v),'stop')==(v,'ok') and accepted(v)
b=copy.deepcopy(v);b['issues']=[{'failure_mode':'F1','severity':'blocking','description':'bad'}]
assert parse(json.dumps(b),'stop')[1]=='ok' and not accepted(b)
assert parse(json.dumps(v),'length')[0] is None
assert parse('{bad','stop')[0] is None
for key,value in [('merge_decision','unknown'),('confidence',True),('issues',None)]:
    b={**v,key:value};assert parse(json.dumps(b),'stop')[0] is None
print('FACTOR_PARSER_ACCEPTANCE_CHECKS_OK')
