#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT=/workspace/users/2022810001/ICSE2027_6658_EndToEnd_GPU_20261109_v21
TASK_MODEL="$1"
TASK_NODE="$2"
TASK_ATTEMPT="$3"
TASK_TAG="icse6658-v21-${TASK_MODEL}-${TASK_ATTEMPT}"
TASK_RUNTIME="/var/tmp/${TASK_TAG}-runtime"
export TASK_COMPILER="/var/tmp/${TASK_TAG}-compiler"
TASK_LOGS="$TASK_ROOT/evidence/${TASK_MODEL}_${TASK_ATTEMPT}"
mkdir "$TASK_LOGS"
export PYTHONUNBUFFERED=1 LOGNAME=2022810001 USER=2022810001
export TMPDIR="/var/tmp/${TASK_TAG}-tmp"
mkdir "$TMPDIR"
export TORCHINDUCTOR_CACHE_DIR="/var/tmp/${TASK_TAG}-inductor"
export TRITON_CACHE_DIR="/var/tmp/${TASK_TAG}-triton"
export VLLM_CACHE_ROOT="/var/tmp/${TASK_TAG}-vllm"
export ZIG_GLOBAL_CACHE_DIR="/var/tmp/${TASK_TAG}-zig-global"
export ZIG_LOCAL_CACHE_DIR="/var/tmp/${TASK_TAG}-zig-local"
export CC="$TASK_COMPILER/cc"
export HF_HUB_OFFLINE=1 TOKENIZERS_PARALLELISM=false VLLM_WORKER_MULTIPROC_METHOD=spawn VLLM_NO_USAGE_STATS=1 DO_NOT_TRACK=1
# Native CUDA12.8/Torch2.8 supports the probed RTX5090. Keep Torch unchanged.
python3 "$TASK_ROOT/tools/prepare_compiler.py" > "$TASK_LOGS/compiler.log" 2>&1
python3 -c "from triton.runtime import driver; print(driver.active.get_current_target())" > "$TASK_LOGS/triton_preflight.log" 2>&1
python3 -m venv --system-site-packages "$TASK_RUNTIME"
"$TASK_RUNTIME/bin/python" -m pip install --no-cache-dir --no-deps --disable-pip-version-check -r "$TASK_ROOT/runtime_requirements.txt" > "$TASK_LOGS/install.log" 2>&1
"$TASK_RUNTIME/bin/python" -c "from vllm.model_executor.models.qwen2 import Qwen2ForCausalLM; print('MODEL_IMPORT_OK')" > "$TASK_LOGS/import.log" 2>&1
"$TASK_RUNTIME/bin/python" "$TASK_ROOT/tools/run_inference.py" "$TASK_MODEL" "$TASK_NODE" "$TASK_ATTEMPT" 2>&1 | tee "$TASK_LOGS/inference.log"
