"""Reuse verified shared compiler archive; install only in ephemeral runtime."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parents[1]
archive=ROOT.parent/'ICSE2027_6658_Rerun_20261106_v14/dependencies/zig-0.13.0.tar.xz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='d45312e61ebcc48032b77bc4cf7fd6915c11fa16e4aad116b66c9468211230ea'
out=Path(os.environ['TASK_COMPILER']);out.mkdir()
with tarfile.open(archive) as t:t.extractall(out,filter='data')
compiler=out/'zig-linux-x86_64-0.13.0/zig';wrapper=out/'cc'
wrapper.write_text('#!/usr/bin/env bash\nexec '+str(compiler)+' cc "$@"\n');wrapper.chmod(0o755)
source=out/'smoke.c';source.write_text('int icse6658_smoke(void) { return 6658; }\n')
subprocess.run([str(wrapper),'-shared','-fPIC',str(source),'-o',str(out/'smoke.so')],check=True)
assert ctypes.CDLL(str(out/'smoke.so')).icse6658_smoke()==6658
print(json.dumps({'archive_sha256_verified':True,'compiler_smoke':True,'version':subprocess.check_output([str(compiler),'version'],text=True).strip()}),flush=True)
