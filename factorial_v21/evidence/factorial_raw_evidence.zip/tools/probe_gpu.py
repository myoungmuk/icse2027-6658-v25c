from pathlib import Path
from datetime import datetime,timezone
import importlib.metadata,json,platform,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
node=sys.argv[1]
record={'node':node,'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'python':platform.python_version(),'python_executable':sys.executable,
        'nvidia_smi':subprocess.check_output(['nvidia-smi'],text=True),'packages':{}}
for name in ['torch','vllm','transformers','triton','xgrammar','outlines','numpy']:
    try:record['packages'][name]=importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:record['packages'][name]=None
import torch
record['cuda_available']=torch.cuda.is_available()
record['gpu_name']=torch.cuda.get_device_name(0)
record['cuda_version']=torch.version.cuda
record['allocation_check']=torch.ones(8,device='cuda').sum().item()==8
record['memory_bytes']=torch.cuda.get_device_properties(0).total_memory
with (ROOT/'evidence'/('gpu_probe_'+node+'.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2),flush=True)
